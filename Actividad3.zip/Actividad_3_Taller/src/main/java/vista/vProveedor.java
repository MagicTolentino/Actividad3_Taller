package vista;

import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;

public class vProveedor extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textEmpresa;
	private JTextField textContacto;
	private JTextField textTelefono;
	private JTextField textCorreo;
	private JTextField textDireccion;
	private JTextField textZona;
	private JLabel lblID;
	private JLabel lblNewLabel;
	private JButton btnAgregar;
	private JButton btnEliminar;
	private JButton btnActualizar;
	private JButton btnLimpiar;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					vProveedor frame = new vProveedor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public vProveedor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 741, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/img/icono.png")));
		setLocationRelativeTo(null);
		setTitle("Proveedores");
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("ID:");
		lblNewLabel.setBounds(16, 16, 95, 16);
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblNewLabel);
		
		lblID = new JLabel("0");
		lblID.setBounds(142, 16, 61, 16);
		lblID.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblID);
		
		JLabel lblEmpresa = new JLabel("Empresa:");
		lblEmpresa.setBounds(16, 44, 95, 16);
		lblEmpresa.setHorizontalAlignment(SwingConstants.RIGHT);
		lblEmpresa.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblEmpresa);
		
		JLabel lblContacto = new JLabel("Contacto:");
		lblContacto.setBounds(16, 72, 95, 16);
		lblContacto.setHorizontalAlignment(SwingConstants.RIGHT);
		lblContacto.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblContacto);
		
		JLabel lblTelefono = new JLabel("Telefono:");
		lblTelefono.setBounds(16, 100, 95, 16);
		lblTelefono.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTelefono.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblTelefono);
		
		JLabel lblCorreo = new JLabel("Correo:");
		lblCorreo.setBounds(16, 128, 95, 16);
		lblCorreo.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCorreo.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblCorreo);
		
		JLabel lblDireccion = new JLabel("Direccion:");
		lblDireccion.setBounds(16, 156, 95, 16);
		lblDireccion.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDireccion.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblDireccion);
		
		JLabel lblZona = new JLabel("Zona:");
		lblZona.setBounds(16, 184, 95, 16);
		lblZona.setHorizontalAlignment(SwingConstants.RIGHT);
		lblZona.setFont(new Font("Arial", Font.BOLD, 14));
		contentPane.add(lblZona);
		
		textEmpresa = new JTextField();
		textEmpresa.setBounds(123, 39, 130, 26);
		contentPane.add(textEmpresa);
		textEmpresa.setColumns(10);
		
		textContacto = new JTextField();
		textContacto.setBounds(123, 67, 130, 26);
		textContacto.setColumns(10);
		contentPane.add(textContacto);
		
		textTelefono = new JTextField();
		textTelefono.setBounds(123, 95, 130, 26);
		textTelefono.setColumns(10);
		contentPane.add(textTelefono);
		
		textCorreo = new JTextField();
		textCorreo.setBounds(123, 123, 130, 26);
		textCorreo.setColumns(10);
		contentPane.add(textCorreo);
		
		textDireccion = new JTextField();
		textDireccion.setBounds(123, 151, 130, 26);
		textDireccion.setColumns(10);
		contentPane.add(textDireccion);
		
		textZona = new JTextField();
		textZona.setBounds(123, 179, 130, 26);
		textZona.setColumns(10);
		contentPane.add(textZona);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.setBounds(77, 217, 117, 29);
		contentPane.add(btnAgregar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(77, 258, 117, 29);
		contentPane.add(btnEliminar);
		
		btnActualizar = new JButton("Actualizar");
		btnActualizar.setBounds(77, 299, 117, 29);
		contentPane.add(btnActualizar);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setBounds(77, 340, 117, 29);
		contentPane.add(btnLimpiar);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(284, 16, 450, 380);
		contentPane.add(scrollPane);
	}
}
